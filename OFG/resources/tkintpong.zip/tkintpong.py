# L0L, something comments created by VS Code [GitHub Copilot, this is AI in VS Code, but working on ChatGPT by OpenAI]
import tkinter
import os
import pygame
import time
folder = os.path.dirname(__file__)
window = tkinter.Tk() # Create a window
window.title("tkintatch")
window.geometry("800x600")
image = tkinter.PhotoImage(file=os.path.join(folder,"harder.png"))
imageTw = tkinter.PhotoImage(file=os.path.join(folder,"harderpong.png"))
icon = tkinter.Label(image=image)
icon.place(x=320,y=100)
icon_positions = [320,100]
pong = tkinter.Label(image=imageTw)
pong.place(x=280,y=340)
pong_x = 0
def move(event):
    pong.place(x=event.x-80) # Move the pong paddle with the mouse
    global pong_x
    pong_x = event.x-80 # Save the x position of the pong paddle for collision detection
velocityY = 0
velocityX = 10
def iconball_physic():
    global velocityY
    global velocityX
    if (icon_positions[1]+120 > 339 and icon_positions[1]+120 < 377 or 358 > icon_positions[1]-velocityY and 358 < icon_positions[1]) and icon_positions[0]+60 >= pong_x and icon_positions[0]+60 <= pong_x+180: # Check if the ball is colliding with the paddle
        icon.place(y=220) # Move the ball to the top of the paddle
        icon_positions[1] = 220 # Update the ball's position to the top of the paddle
        velocityY = -20 # Bounce the ball off the paddle
        velocityX = 10*(0-(icon_positions[0]-400)/abs((icon_positions[0]-400))) # Add horizontal velocity when the ball hits the paddle
    icon.place(x=icon_positions[0]+velocityX,y=icon_positions[1]+velocityY) # Move the ball according to the velocity
    icon_positions[1] += velocityY
    icon_positions[0] += velocityX
    # Update the ball's position
    velocityY +=0.5 # Update the ball's velocity to simulate gravity
    velocityX *= 0.98 # Update the ball's horizontal velocity to simulate friction
    if icon_positions[0] < 1 or icon_positions[0] > 799:
        velocityX = 10*(0-(icon_positions[0]-400)/abs((icon_positions[0]-400)))
    if icon_positions[1] > 599:
        label = tkinter.Label(window,text="FAIL",font=("Arial",50,"bold"),fg="red")
        label.place(x=300,y=100)
        window.after(2000,window.quit) # Remove the "FAIL" label after 2 seconds
    window.after(16,iconball_physic)
window.bind("<Motion>",move)
pygame.mixer.init()
pygame.mixer.music.load(os.path.join(folder,"168734_Jumper.mp3")) # Download music from the file
pygame.mixer.music.play(-1) # Start a infinite music loop
iconball_physic() # Start the ball physics loop
window.mainloop() # Open window and start the loop of all actions